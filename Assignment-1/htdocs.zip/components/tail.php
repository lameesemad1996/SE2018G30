    </main>

    <footer class="footer">
      <div class="container">
        <span class="text-muted">Copyright 2018, Software Engineering Course, ASUENG.</span>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="./js/jquery.min.js">
    <script src="./js/popper.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
  </body>
</html>
